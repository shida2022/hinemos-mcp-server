#!/usr/bin/env python3
"""Example usage of Hinemos Repository API."""

from hinemos_mcp import HinemosClient, RepositoryAPI, IpAddressVersion, SnmpVersion


def main():
    """Example usage of Repository API."""
    # Initialize client
    client = HinemosClient(
        base_url="https://hinemos-manager:8443/HinemosWS/rest",
        username="hinemos",
        password="hinemos",
        verify_ssl=False,  # For development only
    )
    
    # Initialize Repository API
    repo = RepositoryAPI(client)
    
    try:
        # Example 1: Create a scope
        print("Creating scope...")
        scope = repo.create_scope(
            facility_id="EXAMPLE_SCOPE",
            facility_name="Example Scope",
            description="Example scope for testing",
        )
        print(f"Created scope: {scope.facility_id}")
        
        # Example 2: Create a node
        print("Creating node...")
        node = repo.create_node(
            facility_id="EXAMPLE_NODE_01",
            facility_name="Example Node 01",
            ip_address="192.168.1.100",
            description="Example Linux node",
            platform_family="Linux",
            snmp_community="public",
            snmp_version=SnmpVersion.V2,
        )
        print(f"Created node: {node.facility_id}")
        
        # Example 3: Assign node to scope
        print("Assigning node to scope...")
        repo.assign_nodes_to_scope("EXAMPLE_SCOPE", ["EXAMPLE_NODE_01"])
        print("Node assigned to scope")
        
        # Example 4: List all nodes
        print("Listing all nodes...")
        nodes = repo.list_nodes()
        for node in nodes[:5]:  # Show first 5 nodes
            print(f"  - {node.facility_id}: {node.facility_name} ({node.ip_address_v4 or node.ip_address_v6})")
        
        # Example 5: Get facility tree
        print("Getting facility tree...")
        facilities = repo.get_facility_tree()
        for facility in facilities[:10]:  # Show first 10 facilities
            print(f"  - {facility.facility_id}: {facility.facility_name} ({facility.facility_type})")
        
        # Example 6: Ping a node
        print("Pinging node...")
        ping_result = repo.ping_node("EXAMPLE_NODE_01", count=1)
        print(f"Ping result: {ping_result}")
        
        # Example 7: Get agent status
        print("Getting agent status...")
        agent_status = repo.get_agent_status()
        print(f"Found {len(agent_status['agents'])} agents")
        
        # Example 8: Update node
        print("Updating node...")
        updated_node = repo.update_node(
            facility_id="EXAMPLE_NODE_01",
            description="Updated description",
        )
        print(f"Updated node: {updated_node.facility_id}")
        
        # Example 9: Get specific node details
        print("Getting node details...")
        node_details = repo.get_node("EXAMPLE_NODE_01", include_config=True)
        print(f"Node {node_details.facility_id} platform: {node_details.platform_family}")
        
    except Exception as e:
        print(f"Error: {e}")
    
    finally:
        # Cleanup (optional)
        try:
            print("Cleaning up...")
            repo.remove_nodes_from_scope("EXAMPLE_SCOPE", ["EXAMPLE_NODE_01"])
            repo.delete_node("EXAMPLE_NODE_01")
            repo.delete_scope("EXAMPLE_SCOPE")
            print("Cleanup completed")
        except Exception as e:
            print(f"Cleanup error: {e}")
        
        client.close()


if __name__ == "__main__":
    main()