"""Hinemos MCP Server - Model Context Protocol server for Hinemos integration."""

from .server import HinemosMCPServer

__all__ = ["HinemosMCPServer"]